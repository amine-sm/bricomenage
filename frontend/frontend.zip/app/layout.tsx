import type { Metadata } from "next";

import "./globals.css";

import Header from "@/components/Header";
import Footer from "@/components/Footer";
export const metadata: Metadata = {
  title: "BricoMénage | Bricolage, maison et jardin",
  description:
    "Matériel de bricolage, mobilier, jardinage, peinture, plomberie et électricité.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr">
      <body className="bg-[#fafafa] font-sans antialiased">
        <Header />

        {children}
        <Footer/>
      </body>
    </html>
  );
}