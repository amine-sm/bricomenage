export type CartItem={id:number;designation:string;price:number;quantity:number;image?:string};
const KEY="bricomenage_cart";
export const getCart=():CartItem[]=>typeof window==="undefined"?[]:JSON.parse(localStorage.getItem(KEY)||"[]");
export const saveCart=(items:CartItem[])=>{localStorage.setItem(KEY,JSON.stringify(items));window.dispatchEvent(new Event("cart-change"));};
export function addToCart(item:Omit<CartItem,"quantity">){const items=getCart();const found=items.find(x=>x.id===item.id);if(found)found.quantity++;else items.push({...item,quantity:1});saveCart(items);}
