export const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api";
export async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_URL}${path}`, { ...init, headers: { "Content-Type": "application/json", ...(init?.headers || {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || "Erreur du serveur");
  return data as T;
}
