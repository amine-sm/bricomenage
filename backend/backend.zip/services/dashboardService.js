const pool = require("../config/db");

const MONTH_LABELS = [
  "Janv.",
  "Févr.",
  "Mars",
  "Avr.",
  "Mai",
  "Juin",
  "Juil.",
  "Août",
  "Sept.",
  "Oct.",
  "Nov.",
  "Déc.",
];

async function getSingleValue(
  sql,
  params = [],
  field = "total",
) {
  const [rows] = await pool.execute(
    sql,
    params,
  );

  return Number(
    rows?.[0]?.[field] || 0,
  );
}

function getLastSixMonths() {
  const months = [];
  const today = new Date();

  for (let offset = 5; offset >= 0; offset -= 1) {
    const date = new Date(
      today.getFullYear(),
      today.getMonth() - offset,
      1,
    );

    const year = date.getFullYear();
    const monthIndex = date.getMonth();
    const monthNumber = String(
      monthIndex + 1,
    ).padStart(2, "0");

    months.push({
      key: `${year}-${monthNumber}`,
      label: MONTH_LABELS[monthIndex],
      revenue: 0,
      orders: 0,
    });
  }

  return months;
}

async function getDashboardStats() {
  const [
    articles,
    categories,
    suppliers,
    orders,
    revenue,
    lowStock,
    pendingOrders,
    deliveredOrders,
  ] = await Promise.all([
    getSingleValue(`
      SELECT COUNT(*) AS total
      FROM articles
    `),

    getSingleValue(`
      SELECT COUNT(*) AS total
      FROM categories
    `),

    getSingleValue(`
      SELECT COUNT(*) AS total
      FROM suppliers
    `),

    getSingleValue(`
      SELECT COUNT(*) AS total
      FROM orders
    `),

    getSingleValue(`
      SELECT COALESCE(
        SUM(total),
        0
      ) AS total
      FROM orders
      WHERE status <> 'ANNULEE'
    `),

    getSingleValue(`
      SELECT COUNT(*) AS total
      FROM articles
      WHERE stock_quantity <= min_stock
    `),

    getSingleValue(`
      SELECT COUNT(*) AS total
      FROM orders
      WHERE status IN (
        'NOUVELLE',
        'CONFIRMEE',
        'EN_PREPARATION',
        'EXPEDIEE',
        'EN_LIVRAISON'
      )
    `),

    getSingleValue(`
      SELECT COUNT(*) AS total
      FROM orders
      WHERE status = 'LIVREE'
    `),
  ]);

  const [recentOrderRows] =
    await pool.execute(`
      SELECT
        id,
        tracking_number,
        customer_name,
        total,
        status,
        created_at
      FROM orders
      ORDER BY created_at DESC
      LIMIT 8
    `);

  const [salesRows] =
    await pool.execute(`
      SELECT
        DATE_FORMAT(
          created_at,
          '%Y-%m'
        ) AS month_key,

        COUNT(*) AS orders,

        COALESCE(
          SUM(
            CASE
              WHEN status <> 'ANNULEE'
              THEN total
              ELSE 0
            END
          ),
          0
        ) AS revenue

      FROM orders

      WHERE created_at >=
        DATE_SUB(
          DATE_FORMAT(
            CURRENT_DATE,
            '%Y-%m-01'
          ),
          INTERVAL 5 MONTH
        )

      GROUP BY
        DATE_FORMAT(
          created_at,
          '%Y-%m'
        )

      ORDER BY month_key ASC
    `);

  const chartMap = new Map(
    getLastSixMonths().map(
      (month) => [
        month.key,
        month,
      ],
    ),
  );

  salesRows.forEach((row) => {
    const month =
      chartMap.get(row.month_key);

    if (!month) {
      return;
    }

    month.orders = Number(
      row.orders || 0,
    );

    month.revenue = Number(
      row.revenue || 0,
    );
  });

  return {
    stats: {
      articles,
      categories,
      suppliers,
      orders,
      revenue,
      lowStock,
      pendingOrders,
      deliveredOrders,
    },

    recentOrders:
      recentOrderRows.map(
        (order) => ({
          id: Number(order.id),

          tracking_number:
            order.tracking_number,

          customer_name:
            order.customer_name,

          total: Number(
            order.total || 0,
          ),

          status:
            order.status ||
            "NOUVELLE",

          created_at:
            order.created_at,
        }),
      ),

    salesChart:
      Array.from(
        chartMap.values(),
      ).map((month) => ({
        label: month.label,
        revenue: month.revenue,
        orders: month.orders,
      })),
  };
}

module.exports = {
  getDashboardStats,
};
