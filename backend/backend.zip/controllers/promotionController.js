const pool = require('../config/db');
const HttpError = require('../utils/httpError');

const clean = (v) => String(v ?? '').trim();
const activeValue = (v) => (v === false || v === 0 || v === '0' || v === 'false' ? 0 : 1);

function validate(body) {
  const name = clean(body.name);
  const discountType = clean(body.discount_type || 'PERCENT').toUpperCase();
  const discountValue = Number(body.discount_value);
  const articleIds = [...new Set((Array.isArray(body.articleIds) ? body.articleIds : body.articles || []).map(Number).filter(Number.isInteger))];
  if (!name) throw new HttpError(400, 'Le nom de la promotion est obligatoire.');
  if (!['PERCENT', 'FIXED'].includes(discountType)) throw new HttpError(400, 'Type de réduction invalide.');
  if (!Number.isFinite(discountValue) || discountValue <= 0) throw new HttpError(400, 'Valeur de réduction invalide.');
  if (discountType === 'PERCENT' && discountValue > 100) throw new HttpError(400, 'Le pourcentage ne peut pas dépasser 100 %.');
  if (!articleIds.length) throw new HttpError(400, 'Sélectionnez au moins un article.');
  return { name, description: clean(body.description) || null, discountType, discountValue, startsAt: body.starts_at || null, endsAt: body.ends_at || null, isActive: activeValue(body.is_active), articleIds };
}

async function listPromotions(req, res) {
  const [rows] = await pool.query(`SELECT p.*, COUNT(pa.article_id) article_count FROM promotions p LEFT JOIN promotion_articles pa ON pa.promotion_id=p.id GROUP BY p.id ORDER BY p.created_at DESC`);
  res.json({ success: true, promotions: rows.map(r => ({...r, article_count:Number(r.article_count||0)})) });
}
async function getPromotion(req, res) {
  const [[p]] = await pool.query('SELECT * FROM promotions WHERE id=? LIMIT 1',[req.params.id]);
  if (!p) throw new HttpError(404,'Promotion introuvable.');
  const [articles] = await pool.query(`SELECT a.id,a.designation,a.reference,a.image,a.price,a.stock_quantity FROM promotion_articles pa JOIN articles a ON a.id=pa.article_id WHERE pa.promotion_id=? ORDER BY a.designation`,[req.params.id]);
  res.json({...p, articles});
}
async function savePromotion(req,res,isUpdate) {
  const data=validate(req.body); const cn=await pool.getConnection();
  try { await cn.beginTransaction();
    const placeholders=data.articleIds.map(()=>'?').join(',');
    const [[count]] = await cn.query(`SELECT COUNT(*) total FROM articles WHERE id IN (${placeholders})`,data.articleIds);
    if(Number(count.total)!==data.articleIds.length) throw new HttpError(400,'Un article sélectionné est introuvable.');
    let id=Number(req.params.id||0);
    if(isUpdate){ const [r]=await cn.query(`UPDATE promotions SET name=?,description=?,discount_type=?,discount_value=?,starts_at=?,ends_at=?,is_active=? WHERE id=?`,[data.name,data.description,data.discountType,data.discountValue,data.startsAt,data.endsAt,data.isActive,id]); if(!r.affectedRows) throw new HttpError(404,'Promotion introuvable.'); await cn.query('DELETE FROM promotion_articles WHERE promotion_id=?',[id]); }
    else { const [r]=await cn.query(`INSERT INTO promotions(name,description,discount_type,discount_value,starts_at,ends_at,is_active) VALUES(?,?,?,?,?,?,?)`,[data.name,data.description,data.discountType,data.discountValue,data.startsAt,data.endsAt,data.isActive]); id=r.insertId; }
    await cn.query('INSERT INTO promotion_articles(promotion_id,article_id) VALUES ?',[data.articleIds.map(articleId=>[id,articleId])]);
    await cn.commit(); res.status(isUpdate?200:201).json({success:true,message:isUpdate?'Promotion modifiée.':'Promotion créée.',promotion:{id}});
  } catch(e){await cn.rollback(); throw e;} finally {cn.release();}
}
async function createPromotion(req,res){return savePromotion(req,res,false)}
async function updatePromotion(req,res){return savePromotion(req,res,true)}
async function deletePromotion(req,res){const [r]=await pool.query('DELETE FROM promotions WHERE id=?',[req.params.id]); if(!r.affectedRows) throw new HttpError(404,'Promotion introuvable.'); res.json({success:true,message:'Promotion supprimée.'});}
module.exports={listPromotions,getPromotion,createPromotion,updatePromotion,deletePromotion};
