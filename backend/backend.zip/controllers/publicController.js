const articleService=require('../services/articleService'); const catalogService=require('../services/catalogService'); const HttpError=require('../utils/httpError');
async function getArticles(req,res){const data=await articleService.listArticles({search:String(req.query.search||'').trim(),category:String(req.query.category||req.query.categorie||'').trim(),promotion:['1','true'].includes(String(req.query.promotion||'').toLowerCase()),limit:req.query.limit,offset:req.query.offset});res.json({success:true,...data});}
async function getArticleBySlug(req,res){const article=await articleService.findBySlug(String(req.params.slug||'').trim());if(!article)throw new HttpError(404,'Article introuvable.');res.json({success:true,article});}
async function getPacks(req,res){res.json({success:true,packs:await catalogService.listPacks()});}
async function getPackBySlug(req,res){const pack=await catalogService.findPackBySlug(String(req.params.slug||'').trim());if(!pack)throw new HttpError(404,'Pack introuvable.');res.json({success:true,pack});}
async function getPromotions(req,res){res.json({success:true,promotions:await catalogService.listPromotions()});}
module.exports={getArticles,getArticleBySlug,getPacks,getPackBySlug,getPromotions};
