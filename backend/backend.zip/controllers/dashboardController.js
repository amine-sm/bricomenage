const dashboardService =
  require("../services/dashboardService");

async function getDashboard(
  req,
  res,
  next,
) {
  try {
    const dashboard =
      await dashboardService.getDashboardStats();

    return res.status(200).json({
      success: true,
      ...dashboard,
    });
  } catch (error) {
    console.error(
      "Erreur dashboard :",
      error,
    );

    return next(error);
  }
}

module.exports = {
  getDashboard,
};
