const express = require("express");

const {
  requireAdmin,
} = require("../middlewares/auth");

const dashboardController =
  require("../controllers/dashboardController");

const router = express.Router();

router.get(
  "/",
  requireAdmin,
  dashboardController.getDashboard,
);

module.exports = router;