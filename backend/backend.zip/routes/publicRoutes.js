const express=require('express'); const asyncHandler=require('../utils/asyncHandler'); const controller=require('../controllers/publicController'); const router=express.Router();
router.get('/articles',asyncHandler(controller.getArticles)); router.get('/articles/slug/:slug',asyncHandler(controller.getArticleBySlug));
router.get('/packs',asyncHandler(controller.getPacks)); router.get('/packs/slug/:slug',asyncHandler(controller.getPackBySlug)); router.get('/promotions',asyncHandler(controller.getPromotions));
module.exports=router;
